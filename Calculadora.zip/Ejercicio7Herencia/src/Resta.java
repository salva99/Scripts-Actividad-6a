
public class Resta extends Operacion {
	private double resta;
	
	public Resta (double num1, double num2){
		super(num1, num2);
		this.resta=num1-num2;
		super.setResultado(this.resta);
		
		
	}

	public double getResta() {
		return resta;
	}

	public void setResta(double resta) {
		this.resta = resta;
	}
}
