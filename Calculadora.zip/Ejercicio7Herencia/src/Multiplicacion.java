
public class Multiplicacion extends Operacion{
	private double mult;
	
	public Multiplicacion(double num1, double num2) {
		super(num1, num2);
		this.mult=num1*num2;
		super.setResultado(this.mult);
		
		
	}

	public double getMult() {
		return mult;
	}

	public void setMult(double mult) {
		this.mult = mult;
	}

	
}
