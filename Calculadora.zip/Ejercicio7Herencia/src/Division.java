
public class Division extends Operacion {
	private double div;
	
	public Division(double num1, double num2){
		super(num1, num2);
		this.div=num1/num2;
		super.setResultado(this.div);
		
		
	}

	public double getDiv() {
		return div;
	}

	public void setDiv(double div) {
		this.div = div;
	}
	
}
