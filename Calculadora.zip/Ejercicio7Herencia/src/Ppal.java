import java.util.Scanner;

public class Ppal {

	public static void main(String[] args) {
		Operacion o1=new Operacion(1,2);
		o1.mostrarResultado();
		
		
		Scanner sc=new Scanner(System.in);
		int elegir;
		System.out.println("Que operacion desea realizar: 1.Sumar 2.Restar 3.Multiplicar 4.Dividir");
		elegir=sc.nextInt();
		
		switch(elegir) {
		case (1): 
			Suma s1=new Suma(2,3);
			System.out.println(s1.getNum1()+"+"+s1.getNum2()+"="+s1.getSuma());
			break;
		case (2):
			Resta r1=new Resta(5,1);
			System.out.println(r1.getNum1()+"-"+r1.getNum2()+"="+r1.getResta());
			break;
		case (3):
			Multiplicacion m1=new Multiplicacion(10,9);
			System.out.println(m1.getNum1()+"x"+m1.getNum2()+"="+m1.getMult());
			break;
		case (4): 
			Division d1=new Division(8,3);
			System.out.println(d1.getNum1()+"-"+d1.getNum2()+"="+d1.getDiv());
			break;
		}
		
	}

}
