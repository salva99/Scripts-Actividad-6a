
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Poligono p1=new Poligono(2);
		Rectangulo r1=new Rectangulo(2,2,5);
		Triangulo t1=new Triangulo(3, 4.4, 6.5, 2.2);
		
		System.out.println(t1.ToString());
		System.out.println("-----------------------------------------------------");
		System.out.println(r1.ToString());
	}

}
