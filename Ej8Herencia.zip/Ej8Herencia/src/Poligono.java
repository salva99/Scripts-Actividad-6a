
public class Poligono {
	protected int numLados;
	
	public Poligono() {
		
	}
	
	public Poligono(int numLados) {
		this.numLados=numLados;
	}

	public int getNumLados() {
		return numLados;
	}

	public void setNumLados(int numLados) {
		this.numLados = numLados;
	}
	
	public String ToString() {
		return "Poligono de "+this.numLados+" lados-->";
	}
}
